@echo off
echo ========================================================
echo       Building Mayra Assistant APK (Debug)
echo ========================================================
echo Running Gradle build...
call gradlew.bat assembleDebug
echo.
if exist "app\build\outputs\apk\debug\app-debug.apk" (
    echo ========================================================
    echo SUCCESS! APK successfully compiled!
    echo File: app\build\outputs\apk\debug\app-debug.apk
    echo ========================================================
    explorer /select,"app\build\outputs\apk\debug\app-debug.apk"
) else (
    echo Build failed or Android SDK not found. Please open in Android Studio.
)
pause
