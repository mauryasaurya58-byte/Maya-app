#!/bin/bash
echo "========================================================"
echo "      Building Mayra Assistant APK (Debug)"
echo "========================================================"
chmod +x ./gradlew
./gradlew assembleDebug
echo ""
echo "========================================================"
echo "Finished! APK Location: app/build/outputs/apk/debug/app-debug.apk"
echo "========================================================"
