# Mayra Assistant APK - Native Android Source Code

Mayra is a zero-touch, background-running real-time voice assistant built with Kotlin, Jetpack Compose, and the Gemini Live API.

## 🚀 APK Kaise Banaye / How to Build the APK File

ZIP file me complete Android Studio native project code hai. APK file generate karne ke 3 aasan tarike hain:

### Tarika 1: Android Studio me 1-Click (Recommended)
1. Is ZIP ko extract (unzip) karein.
2. **Android Studio** open karein aur `File > Open` par jaakar is extracted folder ko select karein.
3. Gradle sync complete hone ke baad top menu me click karein:
   **Build > Build Bundle(s) / APK(s) > Build APK(s)**
4. Niche notification aayega: *"APK(s) generated successfully: locate"*.
5. `locate` par click karein aur `app-debug.apk` file aapke samne hogi! Ise phone me transfer karke install kar lein.

### Tarika 2: GitHub se Free Cloud Build (Bina PC/Android Studio ke)
1. GitHub.com par login karein aur new private/public repository banayein.
2. Is zip ki files ko GitHub repo me upload kar dein.
3. Repo ke **Actions** tab me jayein, wahan "Build Mayra Assistant APK" automatic run hoga.
4. Build complete hone par **Artifacts** section se direct `MayraAssistant-debug-apk.zip` download karein, jisme direct `app-debug.apk` milega!

### Tarika 3: Terminal ya CMD se Command
- Windows me: `build-apk-windows.bat` par double click karein ya CMD me `gradlew assembleDebug` chalayein.
- Mac / Linux me: Terminal me `./gradlew assembleDebug` chalayein.
- Output file path: `app/build/outputs/apk/debug/app-debug.apk`
