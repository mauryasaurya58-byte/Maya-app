package com.google.aistudio.mayra.audio

import android.annotation.SuppressLint
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.MediaRecorder
import android.media.audiofx.AcousticEchoCanceler
import android.media.audiofx.NoiseSuppressor
import android.util.Log
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlin.math.sqrt

class AudioRecordManager(
    private val onAudioChunk: (ByteArray) -> Unit,
    private val onRmsLevel: (Float) -> Unit = {}
) {
    companion object {
        private const val TAG = "AudioRecordManager"
        const val SAMPLE_RATE = 16000
        const val CHANNEL_CONFIG = AudioFormat.CHANNEL_IN_MONO
        const val AUDIO_FORMAT = AudioFormat.ENCODING_PCM_16BIT
        private const val CHUNK_SIZE = 2048 // ~128ms chunks for low latency
    }

    private var audioRecord: AudioRecord? = null
    private var recordJob: Job? = null
    private val scope = CoroutineScope(Dispatchers.IO)

    @SuppressLint("MissingPermission")
    fun startRecording() {
        val minBufferSize = AudioRecord.getMinBufferSize(SAMPLE_RATE, CHANNEL_CONFIG, AUDIO_FORMAT)
        val bufferSize = maxOf(minBufferSize, CHUNK_SIZE * 4)

        audioRecord = AudioRecord(
            MediaRecorder.AudioSource.VOICE_COMMUNICATION,
            SAMPLE_RATE,
            CHANNEL_CONFIG,
            AUDIO_FORMAT,
            bufferSize
        )

        // Enable hardware Acoustic Echo Cancellation and Noise Suppression if available
        if (AcousticEchoCanceler.isAvailable()) {
            audioRecord?.audioSessionId?.let { AcousticEchoCanceler.create(it)?.enabled = true }
        }
        if (NoiseSuppressor.isAvailable()) {
            audioRecord?.audioSessionId?.let { NoiseSuppressor.create(it)?.enabled = true }
        }

        audioRecord?.startRecording()
        Log.d(TAG, "AudioRecord started at ${SAMPLE_RATE}Hz")

        recordJob = scope.launch {
            val buffer = ByteArray(CHUNK_SIZE)
            while (isActive) {
                val bytesRead = audioRecord?.read(buffer, 0, buffer.size) ?: -1
                if (bytesRead > 0) {
                    val copy = buffer.copyOf(bytesRead)
                    val rms = calculateRms(copy)
                    onRmsLevel(rms)
                    onAudioChunk(copy)
                }
            }
        }
    }

    private fun calculateRms(pcmBytes: ByteArray): Float {
        var sum = 0.0
        val sampleCount = pcmBytes.size / 2
        for (i in 0 until sampleCount) {
            val sample = (pcmBytes[i * 2].toInt() and 0xFF) or (pcmBytes[i * 2 + 1].toInt() shl 8)
            val signedSample = sample.toShort()
            sum += signedSample * signedSample
        }
        val mean = sum / sampleCount
        return (sqrt(mean) / 32768f).coerceIn(0f, 1f)
    }

    fun stopRecording() {
        recordJob?.cancel()
        try {
            audioRecord?.stop()
            audioRecord?.release()
        } catch (e: Exception) {
            Log.e(TAG, "Error stopping AudioRecord", e)
        }
        audioRecord = null
    }
}
