package com.google.aistudio.mayra

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.ContextCompat
import com.google.aistudio.mayra.service.MayraVoiceService
import com.google.aistudio.mayra.ui.MayraScreen
import com.google.aistudio.mayra.ui.theme.MayraTheme

class MainActivity : ComponentActivity() {

    private val requestPermissionsLauncher = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { permissions ->
        val recordAudioGranted = permissions[Manifest.permission.RECORD_AUDIO] == true
        if (recordAudioGranted) {
            startMayraBackgroundService()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        checkAndRequestPermissions()

        setContent {
            MayraTheme {
                MayraScreen(
                    onToggleService = { isRunning ->
                        if (isRunning) {
                            startMayraBackgroundService()
                        } else {
                            stopMayraBackgroundService()
                        }
                    }
                )
            }
        }
    }

    private fun checkAndRequestPermissions() {
        val permissions = mutableListOf(Manifest.permission.RECORD_AUDIO)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            permissions.add(Manifest.permission.POST_NOTIFICATIONS)
        }

        val missing = permissions.filter {
            ContextCompat.checkSelfPermission(this, it) != PackageManager.PERMISSION_GRANTED
        }

        if (missing.isNotEmpty()) {
            requestPermissionsLauncher.launch(missing.toTypedArray())
        } else {
            startMayraBackgroundService()
        }
    }

    private fun startMayraBackgroundService() {
        val intent = Intent(this, MayraVoiceService::class.java).apply {
            action = MayraVoiceService.ACTION_START
        }
        ContextCompat.startForegroundService(this, intent)
    }

    private fun stopMayraBackgroundService() {
        val intent = Intent(this, MayraVoiceService::class.java).apply {
            action = MayraVoiceService.ACTION_STOP
        }
        startService(intent)
    }
}
