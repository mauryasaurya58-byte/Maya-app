package com.google.aistudio.mayra.ui

import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.blur
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.google.aistudio.mayra.service.MayraVoiceService

@Composable
fun MayraScreen(
    onToggleService: (Boolean) -> Unit
) {
    val assistantState by MayraVoiceService.assistantState.collectAsState()
    var isListeningEnabled by remember { mutableStateOf(true) }

    // Pulsing animation for the organic aura
    val infiniteTransition = rememberInfiniteTransition(label = "MayraAura")
    val pulseScale by infiniteTransition.animateFloat(
        initialValue = 0.95f,
        targetValue = 1.15f,
        animationSpec = infiniteRepeatable(
            animation = tween(1200, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "pulse"
    )

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF0D0B14))
            .padding(24.dp)
    ) {
        // Zero-touch Voice Aura Visualizer in Center
        Column(
            modifier = Modifier.align(Alignment.Center),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Box(
                contentAlignment = Alignment.Center,
                modifier = Modifier.size(280.dp)
            ) {
                // Background ambient glow
                Canvas(
                    modifier = Modifier
                        .size(240.dp * pulseScale)
                        .blur(32.dp)
                ) {
                    drawCircle(
                        brush = Brush.radialGradient(
                            colors = listOf(
                                Color(0xFFFF2D85).copy(alpha = 0.6f),
                                Color(0xFF8B5CF6).copy(alpha = 0.4f),
                                Color.Transparent
                            )
                        )
                    )
                }

                // Core reactive sphere
                Box(
                    modifier = Modifier
                        .size(170.dp)
                        .clip(CircleShape)
                        .background(
                            Brush.sweepGradient(
                                listOf(
                                    Color(0xFFFF2D85),
                                    Color(0xFF8B5CF6),
                                    Color(0xFF00F0FF),
                                    Color(0xFFFF2D85)
                                )
                            )
                        )
                )
            }

            Spacer(modifier = Modifier.height(32.dp))

            Text(
                text = "MAYRA",
                fontSize = 32.sp,
                fontWeight = FontWeight.Black,
                color = Color.White,
                letterSpacing = 4.sp
            )

            Text(
                text = when (assistantState) {
                    "Speaking" -> "Talking with attitude..."
                    "Interrupted" -> "Listening to your interruption..."
                    "Connecting" -> "Connecting live..."
                    else -> "Casual & Listening (Zero-Touch)"
                },
                fontSize = 15.sp,
                color = Color(0xFFE2D9F3).copy(alpha = 0.8f),
                textAlign = TextAlign.Center
            )
        }

        // Bottom Controls: Background Service Toggle
        Row(
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .fillMaxWidth()
                .padding(bottom = 16.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(
                    text = "Background Voice Service",
                    fontSize = 14.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = Color.White
                )
                Text(
                    text = "Always listening even when phone is locked",
                    fontSize = 12.sp,
                    color = Color.Gray
                )
            }
            Switch(
                checked = isListeningEnabled,
                onCheckedChange = {
                    isListeningEnabled = it
                    onToggleService(it)
                }
            )
        }
    }
}
