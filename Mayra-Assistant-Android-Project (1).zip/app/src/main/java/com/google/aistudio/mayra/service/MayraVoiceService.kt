package com.google.aistudio.mayra.service

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import android.os.PowerManager
import androidx.core.app.NotificationCompat
import com.google.aistudio.mayra.MainActivity
import com.google.aistudio.mayra.R
import com.google.aistudio.mayra.audio.AudioRecordManager
import com.google.aistudio.mayra.audio.AudioTrackPlayer
import com.google.aistudio.mayra.network.GeminiLiveClient
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

class MayraVoiceService : Service() {

    companion object {
        const val ACTION_START = "ACTION_START_MAYRA"
        const val ACTION_STOP = "ACTION_STOP_MAYRA"
        private const val NOTIFICATION_ID = 2026
        private const val CHANNEL_ID = "mayra_voice_service_channel"

        private val _assistantState = MutableStateFlow("Idle")
        val assistantState = _assistantState.asStateFlow()
    }

    private val serviceScope = CoroutineScope(Dispatchers.IO + SupervisorJob())
    private var wakeLock: PowerManager.WakeLock? = null

    private lateinit var audioRecordManager: AudioRecordManager
    private lateinit var audioTrackPlayer: AudioTrackPlayer
    private lateinit var geminiLiveClient: GeminiLiveClient

    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()

        val powerManager = getSystemService(Context.POWER_SERVICE) as PowerManager
        wakeLock = powerManager.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "Mayra:BackgroundListeningWakeLock")
        wakeLock?.acquire(24 * 60 * 60 * 1000L) // 24 hours

        audioTrackPlayer = AudioTrackPlayer()
        geminiLiveClient = GeminiLiveClient(
            onAudioChunkReceived = { pcm24kData ->
                _assistantState.value = "Speaking"
                audioTrackPlayer.playPcm(pcm24kData)
            },
            onInterrupted = {
                _assistantState.value = "Interrupted"
                audioTrackPlayer.stopAndFlush()
            },
            onTurnCompleted = {
                _assistantState.value = "Listening"
            }
        )

        audioRecordManager = AudioRecordManager(
            onAudioChunk = { pcm16kBytes ->
                // Check if user spoke while assistant was playing -> local VAD interrupt
                if (audioTrackPlayer.isPlaying()) {
                    audioTrackPlayer.stopAndFlush()
                    geminiLiveClient.sendInterrupt()
                    _assistantState.value = "Listening"
                }
                geminiLiveClient.sendAudio(pcm16kBytes)
            }
        )
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_START -> startForegroundListening()
            ACTION_STOP -> stopListening()
        }
        return START_STICKY
    }

    private fun startForegroundListening() {
        val notification = buildNotification("Mayra is active and listening...")
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            startForeground(
                NOTIFICATION_ID,
                notification,
                ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE
            )
        } else {
            startForeground(NOTIFICATION_ID, notification)
        }

        serviceScope.launch {
            _assistantState.value = "Connecting"
            geminiLiveClient.connect()
            audioRecordManager.startRecording()
            _assistantState.value = "Listening"
        }
    }

    private fun stopListening() {
        audioRecordManager.stopRecording()
        audioTrackPlayer.release()
        geminiLiveClient.disconnect()
        wakeLock?.let { if (it.isHeld) it.release() }
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    private fun buildNotification(status: String): Notification {
        val pendingIntent = PendingIntent.getActivity(
            this,
            0,
            Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE
        )

        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("Mayra Voice Assistant")
            .setContentText(status)
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setContentIntent(pendingIntent)
            .setOngoing(true)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .build()
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "Mayra Voice Assistant",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "Background continuous voice streaming with Gemini Live"
            }
            val manager = getSystemService(NotificationManager::class.java)
            manager.createNotificationChannel(channel)
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onDestroy() {
        super.onDestroy()
        serviceScope.cancel()
        stopListening()
    }
}
