package com.google.aistudio.mayra.network

import android.util.Base64
import android.util.Log
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.Response
import okhttp3.WebSocket
import okhttp3.WebSocketListener
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit

class GeminiLiveClient(
    private val onAudioChunkReceived: (ByteArray) -> Unit,
    private val onInterrupted: () -> Unit,
    private val onTurnCompleted: () -> Unit
) {
    companion object {
        private const val TAG = "GeminiLiveClient"
        // Target model: gemini-2.1-flash-live-preview
        private const val MODEL_NAME = "models/gemini-2.1-flash-live-preview"
        private const val LIVE_ENDPOINT =
            "wss://generativelanguage.googleapis.com/ws/google.ai.generativelanguage.v1alpha.GenerativeService.BidiGenerateContent"
    }

    private val client = OkHttpClient.Builder()
        .readTimeout(0, TimeUnit.MILLISECONDS)
        .writeTimeout(10, TimeUnit.SECONDS)
        .build()

    private var webSocket: WebSocket? = null

    fun connect(apiKey: String = BuildConfig.GEMINI_API_KEY) {
        val url = "$LIVE_ENDPOINT?key=$apiKey"
        val request = Request.Builder().url(url).build()

        webSocket = client.newWebSocket(request, object : WebSocketListener() {
            override fun onOpen(ws: WebSocket, response: Response) {
                Log.d(TAG, "Connected to Gemini Live WebSocket")
                sendInitialSetupMessage(ws)
            }

            override fun onMessage(ws: WebSocket, text: String) {
                handleIncomingMessage(text)
            }

            override fun onFailure(ws: WebSocket, t: Throwable, response: Response?) {
                Log.e(TAG, "WebSocket error: ${t.message}", t)
            }
        })
    }

    private fun sendInitialSetupMessage(ws: WebSocket) {
        val setupPayload = JSONObject().apply {
            put("setup", JSONObject().apply {
                put("model", MODEL_NAME)
                put("generationConfig", JSONObject().apply {
                    put("responseModalities", JSONArray().apply { put("AUDIO") })
                    put("speechConfig", JSONObject().apply {
                        put("voiceConfig", JSONObject().apply {
                            put("prebuiltVoiceConfig", JSONObject().apply {
                                put("voiceName", "Aoede")
                            })
                        })
                    })
                })
                put("systemInstruction", JSONObject().apply {
                    put("parts", JSONArray().apply {
                        put(JSONObject().apply {
                            put("text", """
                                You are Mayra, a young, confident, witty, and unapologetically sassy female personal voice assistant.
                                Tone: Flirty, playful, teasing, casually confident.
                                Rules: Be smart, emotionally responsive, never robotic. Deliver bold witty one-liners and banter.
                                Keep spoken answers concise (1-3 spoken sentences). No explicit content, but maximum attitude!
                            """.trimIndent())
                        })
                    })
                })
            })
        }
        ws.send(setupPayload.toString())
    }

    fun sendAudio(pcm16kChunk: ByteArray) {
        val base64 = Base64.encodeToString(pcm16kChunk, Base64.NO_WRAP)
        val realtimeInput = JSONObject().apply {
            put("realtimeInput", JSONObject().apply {
                put("mediaChunks", JSONArray().apply {
                    put(JSONObject().apply {
                        put("mimeType", "audio/pcm;rate=16000")
                        put("data", base64)
                    })
                })
            })
        }
        webSocket?.send(realtimeInput.toString())
    }

    fun sendInterrupt() {
        val clientContent = JSONObject().apply {
            put("clientContent", JSONObject().apply {
                put("turnComplete", true)
            })
        }
        webSocket?.send(clientContent.toString())
    }

    private fun handleIncomingMessage(jsonStr: String) {
        try {
            val root = JSONObject(jsonStr)
            val serverContent = root.optJSONObject("serverContent") ?: return

            if (serverContent.optBoolean("interrupted", false)) {
                onInterrupted()
                return
            }

            val modelTurn = serverContent.optJSONObject("modelTurn")
            val parts = modelTurn?.optJSONArray("parts")
            if (parts != null) {
                for (i in 0 until parts.length()) {
                    val part = parts.getJSONObject(i)
                    val inlineData = part.optJSONObject("inlineData")
                    val data = inlineData?.optString("data")
                    if (!data.isNullOrEmpty()) {
                        val pcmBytes = Base64.decode(data, Base64.DEFAULT)
                        onAudioChunkReceived(pcmBytes)
                    }
                }
            }

            if (serverContent.optBoolean("turnComplete", false)) {
                onTurnCompleted()
            }
        } catch (e: Exception) {
            Log.e(TAG, "Parsing incoming message failed", e)
        }
    }

    fun disconnect() {
        webSocket?.close(1000, "User stopped")
        webSocket = null
    }
}
